/**
 * @author Frank 
 * Acesando o pacote jpaUtilDAO.
 */
package br.com.testeif.jpaUtilDAO;
// https://www.youtube.com/watch?v=DN8Jh-xdejU
/**
 * @author Frank 
 * O pacote jpaUtilDAO serve
 * para gerenciar os dados
 * para o banco e tambem 
 * cria o banco de dados.
 */