/**
 * @author Frank 
 * Acesando o pacote app.
 */
package br.com.testeif.app;
/**
 * @author Frank
 * Serve como um instru��o de como 
 * o banco tem que ser criado.
 */
/* SQL
CREATE SCHEMA `pizza_ifmss` DEFAULT CHARACTER SET utf8 ;
drop database pizza_ifms;
create database pizza_ifms;
*/
/**
 * @author Frank
 * O pacote app serve como um 
 * iniciador do projeto
 * durante cria��o do programa, 
 */
