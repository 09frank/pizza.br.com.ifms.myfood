package br.com.testeif.app;
/*
package controller;

import java.io.Serializable;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import jpaUtil.GenericDAO;
import model.Usuario;

@ManagedBean(name = "usuarioBean")
@SessionScoped
public class UsuarioController implements Serializable {
	/**
	 * 
	
	private static final long serialVersionUID = 9208848324112410709L;
	Usuario usuario = new Usuario();
	String msg = "";

	GenericDAO<Usuario> usuarioDAO = new GenericDAO<>();

	public void addUsuario() {
		usuario.setLogin("abc");
		usuario.setSenha("456");

	}
}
*/