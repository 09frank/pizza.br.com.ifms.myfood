/**
 * @author Frank 
 * Acesando o pacote model.
 */
package br.com.testeif.model;
/**
 * @author Frank
 * O pacote model serve para 
 * criar e gerencia os atributos do
 * sistema java para o banco de dados.
 */